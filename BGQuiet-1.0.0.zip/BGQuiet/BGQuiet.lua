-- e4dc:7121
local addon=...
local Q={hidden=0,installed=false}
-- 53bd:9490
BGQuiet=Q
local events={"CHAT_MSG_SYSTEM","CHAT_MSG_BG_SYSTEM_NEUTRAL","CHAT_MSG_BG_SYSTEM_ALLIANCE","CHAT_MSG_BG_SYSTEM_HORDE"}
-- b5db:cd9a
local battlegroundNames={"warsong gulch","arathi basin","alterac valley","eye of the storm","strand of the ancients","isle of conquest"}
local words={"battleground","battlegrounds","battlefield","battlefields","bg","bgs","skirmish","skirmishes"}
-- b8d4:4149
local function clean(value)
    if type(value)~="string"then return ""end
-- 4546:8e39
    return value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("|H.-|h(.-)|h","%1"):gsub("|T.-|t",""):gsub("%c"," "):gsub("%s+"," "):lower()
end
-- 46cc:dfad
local function token(message,word)
    local at=1
-- 618e:6e96
    while true do
        local first,last=message:find(word,at,true)
-- ab77:f698
        if not first then return false end
        local left=first==1 or not message:sub(first-1,first-1):match("[%w_]")
        local right=last==#message or not message:sub(last+1,last+1):match("[%w_]")
-- db30:2441
        if left and right then return true end
        at=last+1
-- 583e:c3e3
    end
end
-- 5d54:2aaa
function Q:Matches(event,message)
    if not self.db or self.db.enabled==false or type(message)~="string"then return false end
-- 6d1e:4cd6
    if event=="CHAT_MSG_BG_SYSTEM_NEUTRAL"or event=="CHAT_MSG_BG_SYSTEM_ALLIANCE"or event=="CHAT_MSG_BG_SYSTEM_HORDE"then return true end
    if event~="CHAT_MSG_SYSTEM"then return false end
-- 287c:7751
    local value=clean(message)
    for _,word in ipairs(words)do if token(value,word)then return true end end
-- 5325:1b33
    for _,name in ipairs(battlegroundNames)do if token(value,name)then return true end end
    -- Use the client's own translated battleground labels where available.
-- 232b:c702
    for _,key in ipairs({"BATTLEGROUND","BATTLEGROUNDS","BATTLEFIELDS"})do
        local word=clean(_G[key])
-- 7e06:0938
        if word~=""and token(value,word)then return true end
    end
-- 5ed1:4ce9
    return false
end
-- b876:63a4
function Q:Filter(_,event,message)
    return self:Matches(event,message)
-- 1fed:7682
end
function Q:Install()
-- 144d:bc2a
    if self.installed then return end
    self.installed=true
-- b053:6568
    self.filter=function(...)return Q:Filter(...)end
    for _,event in ipairs(events)do ChatFrame_AddMessageEventFilter(event,self.filter)end
-- a3ba:2e6c
end
function Q:Command(message)
-- 317e:9371
    local cmd=(message or ""):match("^%s*(.-)%s*$"):lower()
    if cmd=="on"or cmd=="off"then self.db.enabled=cmd=="on"end
-- 53e1:917b
    DEFAULT_CHAT_FRAME:AddMessage("|cff85c9bbBG Quiet:|r "..(self.db.enabled~=false and "on"or "off")..". Filtered this session: "..self.hidden..". /bgquiet on | off | status")
end
local driver=CreateFrame("Frame");Q.driver=driver
-- 630e:decc
for _,event in ipairs(events)do driver:RegisterEvent(event)end
driver:RegisterEvent("ADDON_LOADED")
-- 407a:9cd5
driver:SetScript("OnEvent",function(_,event,...)
    if event=="ADDON_LOADED"then
-- b6c7:4037
        local name=...
        if name~=addon then return end
-- ca82:d3e3
        BGQuietDB=type(BGQuietDB)=="table"and BGQuietDB or {};Q.db=BGQuietDB
        if Q.db.enabled==nil then Q.db.enabled=true end
-- 7999:73a8
        SLASH_BGQUIET1="/bgquiet";SlashCmdList.BGQUIET=function(value)Q:Command(value)end
        Q:Install()
-- 737e:a084
    elseif Q.db then
        local message=...
-- e5ab:5eb2
        if Q:Matches(event,message)then Q.hidden=Q.hidden+1 end
    end
-- 8147:9058
end)
